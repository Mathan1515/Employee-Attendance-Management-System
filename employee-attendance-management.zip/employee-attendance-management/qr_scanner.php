<?php
// qr_scanner.php
session_start();
include('includes/connection.php');
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>Employee QR Scanner</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="assets/css/bootstrap.min.css">
    <script src="https://unpkg.com/html5-qrcode" type="text/javascript"></script>
    <style>
        #reader { width: 350px; margin: 0 auto; }
        .emp-details { margin-top: 30px; }
    </style>
</head>
<body>
<div class="container mt-5">
    <h2 class="text-center mb-4">Scan Employee QR Code</h2>
    <div id="reader"></div>
    <div id="emp-details" class="emp-details"></div>
</div>
<script>
function showEmployeeDetails(data) {
    if (!data || data.status === 'error') {
        document.getElementById('emp-details').innerHTML = '<div class="alert alert-danger">Employee not found.</div>';
        return;
    }
    let html = `<div class='card'><div class='card-body'>
        <h4 class='card-title'>${data.first_name} ${data.last_name}</h4>
        <p><strong>Employee ID:</strong> ${data.employee_id}</p>
        <p><strong>Department:</strong> ${data.department}</p>
        <p><strong>Email:</strong> ${data.emailid}</p>
        <p><strong>Phone:</strong> ${data.phone}</p>
        <p><strong>Gender:</strong> ${data.gender}</p>
        <p><strong>Shift:</strong> ${data.shift}</p>
        <img src='${data.profile_image}' alt='Profile Image' class='rounded-circle' width='120' height='120' style='object-fit:cover;'>
    </div></div>`;
    document.getElementById('emp-details').innerHTML = html;
}

function fetchEmployeeDetails(empId) {
    fetch('get_employee_details.php?id=' + encodeURIComponent(empId))
        .then(response => response.json())
        .then(data => showEmployeeDetails(data))
        .catch(() => showEmployeeDetails({status: 'error'}));
}

const html5QrCode = new Html5Qrcode("reader");
Html5Qrcode.getCameras().then(devices => {
    if (devices && devices.length) {
        html5QrCode.start(
            { facingMode: "environment" },
            { fps: 10, qrbox: 250 },
            qrCodeMessage => {
                html5QrCode.stop();
                // Assume QR code contains employee ID
                fetchEmployeeDetails(qrCodeMessage.trim());
            },
            errorMessage => {
                // ignore errors
            })
    }
}).catch(err => {
    document.getElementById('emp-details').innerHTML = '<div class="alert alert-danger">Camera not found or not accessible.</div>';
});
</script>
</body>
</html> 